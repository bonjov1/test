package watcher;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;

import watcher.WatcherApplication;
import watcher.core.Checker;
import watcher.core.Notifier;
import watcher.domain.Watch;
import watcher.domain.WatchHistory;
import watcher.repository.WatchHistoryRepository;
import watcher.repository.WatchRepository;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

import java.time.LocalDateTime;


@RunWith(MockitoJUnitRunner.class)
public class WatcherApplicationUnitTests {

    @InjectMocks
    private WatcherApplication app;

    @Mock
    private WatchHistoryRepository watchHistoryRepository; 

    @Mock
    private WatchRepository watchRepository;

    @Mock
    private Checker checker;

    @Mock
    private Notifier notifier;

    private Watch watch;

    private ArgumentCaptor<WatchHistory> argument;

    @Before
    public void setup() {
        watch = new Watch();
        watch.setWatchName("Syslog watch");
        argument = ArgumentCaptor.forClass(WatchHistory.class);
    } 

    @Test
    public void whenActivatedAndNotThrottledSendNotificationAndLog() {
        when(checker.isActivated()).thenReturn(true);
        when(checker.shouldNotify()).thenReturn(true);

        app.processWatch(watch);

        verify(checker, times(1)).init(watch);
        verify(checker, times(1)).isActivated();
        verify(checker, times(1)).shouldNotify();
        verify(notifier, times(1)).sendNotification(watch);
        verify(watchHistoryRepository).save(argument.capture());
        assertEquals("Syslog watch", argument.getValue().getWatchName());
        assertEquals(true, argument.getValue().isActivated());
        assertEquals(true, argument.getValue().isNotified());

    }

    @Test
    public void whenNotActivatedDoNotSendNotificationAndJustLog() {
        when(checker.isActivated()).thenReturn(false);
        when(checker.shouldNotify()).thenReturn(true);

        app.processWatch(watch);

        verify(checker, times(1)).init(watch);
        verify(checker, times(1)).isActivated();
        verify(checker, times(0)).shouldNotify();
        verify(notifier, times(0)).sendNotification(watch);
        verify(watchHistoryRepository).save(argument.capture());
        assertEquals("Syslog watch", argument.getValue().getWatchName());
        assertEquals(false, argument.getValue().isActivated());
        assertEquals(false, argument.getValue().isNotified());

    }

    @Test
    public void whenActivatedButThrottledDoNotSendNotoficationAndJustLog() {
        when(checker.isActivated()).thenReturn(true);
        when(checker.shouldNotify()).thenReturn(false);

        app.processWatch(watch);

        verify(checker, times(1)).init(watch);
        verify(checker, times(1)).isActivated();
        verify(checker, times(1)).shouldNotify();
        verify(notifier, times(0)).sendNotification(watch);
        verify(watchHistoryRepository).save(argument.capture());
        assertEquals("Syslog watch", argument.getValue().getWatchName());
        assertEquals(true, argument.getValue().isActivated());
        assertEquals(false, argument.getValue().isNotified());

    }
}
