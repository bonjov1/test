package watcher;

import static org.mockito.Mockito.*;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.data.elasticsearch.core.ResultsExtractor;
import org.springframework.data.elasticsearch.core.query.SearchQuery;

import watcher.core.Checker;
import watcher.domain.SearchResult;
import watcher.domain.Watch;
import watcher.domain.WatchHistory;
import watcher.repository.WatchHistoryRepository;


@RunWith(MockitoJUnitRunner.class)
public class CheckerUnitTest {

    @Mock
    private ElasticsearchTemplate elasticsearchTemplate;

    @Mock
    private WatchHistoryRepository watchHistoryRepository;

    private Watch watch;

    @InjectMocks
    private Checker checker;

    private ArgumentCaptor<String> watchName;
    private ArgumentCaptor<String> from;
    private ArgumentCaptor<String> to;
    private ArgumentCaptor<Boolean> notified;

    @Before
    public void setup() {
        watch = new Watch("Some watch", "ind", "\"{match_all\"}", "0", "log", 3);
        SearchResult results = new SearchResult(2);
        checker.init(watch);
        when(elasticsearchTemplate.query(any(), any()))
            .thenReturn(results);
        watchName = ArgumentCaptor.forClass(String.class);
        from = ArgumentCaptor.forClass(String.class);
        to = ArgumentCaptor.forClass(String.class);
        notified = ArgumentCaptor.forClass(Boolean.class);
    }

    @Test
    public void testIsActivatedReturnsTrue() {
        watch.setCondition("1");
        assertEquals(true, checker.isActivated());
    }

    @Test
    public void testIsActivatedReturnsFalse() {
        watch.setCondition("3");
        assertEquals(false, checker.isActivated());
    }

    @Test
    public void testShouldNotifyReturnsFalse() {
        when(watchHistoryRepository
            .findByWatchNameAndTimestampBetweenAndNotified(
                any(String.class), any(String.class), any(String.class), any(Boolean.class)))
            .thenReturn(Arrays.asList(new WatchHistory(), new WatchHistory()));

        boolean shouldNotify = checker.shouldNotify();
        
        verify(watchHistoryRepository)
            .findByWatchNameAndTimestampBetweenAndNotified(
                    watchName.capture(), 
                    from.capture(),
                    to.capture(),
                    notified.capture());
        LocalDateTime fromTimestamp = LocalDateTime.parse(from.getValue());
        LocalDateTime toTimestamp = LocalDateTime.parse(to.getValue());

        assertEquals(
            fromTimestamp.getSecond(),
            toTimestamp.minusSeconds(watch.getThrottleTimeSeconds()).getSecond()
        );
        assertEquals(false, shouldNotify);
    }

    @Test
    public void testShouldNotifyReturnsTrue() {
        when(watchHistoryRepository
            .findByWatchNameAndTimestampBetweenAndNotified(
                any(String.class), any(String.class), any(String.class), any(Boolean.class)))
            .thenReturn(Arrays.asList());

        boolean notified = checker.shouldNotify();

        assertEquals(true, notified);
    }
}
