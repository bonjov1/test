package watcher;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Sort;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.data.elasticsearch.core.query.IndexQuery;
import org.springframework.data.elasticsearch.core.query.IndexQueryBuilder;
import org.springframework.test.context.junit4.SpringRunner;

import watcher.WatcherApplication;
import watcher.domain.Watch;
import watcher.domain.WatchHistory;
import watcher.repository.WatchHistoryRepository;
import watcher.repository.WatchRepository;

import static org.junit.Assert.*;


@RunWith(SpringRunner.class)
@SpringBootTest
public class IntegrationTests {

    @Autowired
    private WatcherApplication app;

    @Autowired
    private WatchHistoryRepository watchHistoryRepository; 

    @Autowired
    private WatchRepository watchRepository;

    @Autowired
    private ElasticsearchTemplate elasticsearchTemplate;

    @Before
    public void setup() {
        watchHistoryRepository.deleteAll();
        watchRepository.deleteAll();
        elasticsearchTemplate.deleteIndex(TestEntity.class);
        
        
        elasticsearchTemplate.createIndex(TestEntity.class);
        for (int i=0; i<5; i++) {
            TestEntity testEnity = new TestEntity("Message "+i);
            elasticsearchTemplate.index(getIndexQuery(testEnity));
            elasticsearchTemplate.refresh(TestEntity.class);
        }

    }

    @Test
    public void itWontActivate() throws Exception {
        Watch testWatch = new Watch(
            "Test watch", "test-index", "{\"match_all\":{}}", "6", "logit", 60);
        watchRepository.save(testWatch);
        
        app.run();

        Iterable<WatchHistory> entries = watchHistoryRepository
            .findAll(new Sort(new Sort.Order(Sort.Direction.DESC,"timestamp")));
        WatchHistory watchEntry = entries.iterator().next();
        assertEquals(false, watchEntry.isActivated());
    }


    @Test
    public void itWontNotifySecondRun() throws Exception {
        Watch testWatch = new Watch(
            "Test watch", "test-index", "{\"match_all\":{}}", "2", "logit", 60);
        watchRepository.save(testWatch);

        app.run();

        assertEquals(1, watchHistoryRepository.count());
        Iterable<WatchHistory> entries = watchHistoryRepository
            .findAll(new Sort(new Sort.Order(Sort.Direction.DESC,"timestamp")));
        entries.forEach(e -> assertEquals(true, e.isActivated()));
        entries.forEach(e -> assertEquals(true, e.isNotified()));

        app.run();

        entries = watchHistoryRepository
            .findAll(new Sort(new Sort.Order(Sort.Direction.DESC,"timestamp")));
        WatchHistory watchEntry = entries.iterator().next();
        assertEquals(true, watchEntry.isActivated());
        assertEquals(false, watchEntry.isNotified());
    }

    private IndexQuery getIndexQuery(TestEntity testEntity) {
            return new IndexQueryBuilder()
                .withId(testEntity.getId())
                .withObject(testEntity).build();
    }

}
