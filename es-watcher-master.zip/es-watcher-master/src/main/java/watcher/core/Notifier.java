package watcher.core;

import org.springframework.stereotype.Component;

import watcher.domain.Watch;


public interface Notifier {
    public void sendNotification(Watch watch);
}

@Component
class NotifierImpl implements Notifier {

    public void sendNotification(Watch watch) {
        //TODO Implement notifications; email, post to web service
        return; 
    }

}
