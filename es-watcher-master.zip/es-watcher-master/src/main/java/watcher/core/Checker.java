package watcher.core;

import java.time.LocalDateTime;
import java.util.List;

import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.QueryBuilders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.elasticsearch.core.ElasticsearchTemplate;
import org.springframework.data.elasticsearch.core.ResultsExtractor;
import org.springframework.data.elasticsearch.core.query.NativeSearchQueryBuilder;
import org.springframework.data.elasticsearch.core.query.SearchQuery;
import org.springframework.stereotype.Component;

import watcher.domain.SearchResult;
import watcher.domain.Watch;
import watcher.domain.WatchHistory;
import watcher.repository.WatchHistoryRepository;


@Component
//TODO Use interface
public class Checker {

    @Autowired
    private ElasticsearchTemplate elasticsearchTemplate;

    @Autowired
    private WatchHistoryRepository watchHistoryRepository;

    private Watch watch;

    private SearchQuery searchQuery;

    public boolean shouldNotify() {
        LocalDateTime to = LocalDateTime.now();
        LocalDateTime from =  LocalDateTime.now()
            .minusSeconds(watch.getThrottleTimeSeconds());
        List<WatchHistory> results = watchHistoryRepository
            .findByWatchNameAndTimestampBetweenAndNotified(
                watch.getWatchName(), from.toString(), to.toString(), true);
        if (results.size() > 0) {
            return false;
        }
        return true;
    }

    public boolean isActivated() {
        SearchResult results = elasticsearchTemplate
            .query(searchQuery, new ResultsExtractor<SearchResult>() {
               @Override
               public SearchResult extract(SearchResponse response) {
                   long totalHits = response.getHits().totalHits();
                   return new SearchResult(totalHits);
               }
            });

        if (results.getTotalHits() > Integer.parseInt(watch.getCondition())) {
            return true;
        }
        return false;
    }

    /**
     * @param watch the watch to set
     */
    public void init(Watch watch) {
        this.searchQuery = new NativeSearchQueryBuilder()
            .withIndices(watch.getIndex())
            .withQuery(QueryBuilders.wrapperQuery(watch.getQuery()))
            .build();
        this.watch = watch;
    }

    /**
     * @return the searchQuery
     */
    public SearchQuery getSearchQuery() {
        return searchQuery;
    }
}
