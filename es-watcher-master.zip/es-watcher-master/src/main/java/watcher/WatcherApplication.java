package watcher;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import watcher.core.Checker;
import watcher.core.Notifier;
import watcher.domain.Watch;
import watcher.domain.WatchHistory;
import watcher.repository.WatchHistoryRepository;
import watcher.repository.WatchRepository;


@SpringBootApplication
public class WatcherApplication implements CommandLineRunner {

    @Autowired
    private WatchHistoryRepository watchHistoryRepository;

    @Autowired
    private WatchRepository watchRepository;

    @Autowired
    private Notifier notifier;

    @Autowired
    private Checker checker;

    @Override
    public void run(String... arg0) throws Exception {
        Iterable<Watch> watch = watchRepository.findAll();
        watch.forEach(w -> processWatch(w));
    }

    public void processWatch(Watch watch) {
        boolean activated = false;
        boolean notified = false;
        checker.init(watch);
        if (checker.isActivated()) {
            activated = true;
            if(checker.shouldNotify()) {
                notifier.sendNotification(watch);
                notified = true;
            }
        }
        WatchHistory watchHistory = new WatchHistory(
            LocalDateTime.now().toString(), watch.getWatchName(), activated, notified);

        watchHistoryRepository.save(watchHistory);
    }

    public static void main(String[] args) throws Exception {
        SpringApplication.run(WatcherApplication.class, args).close();
    }
}
