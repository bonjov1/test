package watcher.domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;


@Document(indexName="watch", type="entry", shards=1, replicas=0, refreshInterval="-1")
public class Watch {

    @Id
    private String id;
    private String watchName;
    private String index;
    private String query;
    private String condition;
    private String action;
    private int throttleTimeSeconds;

    /**
     * @param watchName
     * @param index
     * @param query
     * @param condition
     * @param action
     * @param throttleTimeSeconds
     */
    public Watch(String watchName, String index, String query, String condition, String action,
            int throttleTimeSeconds) {
        this.watchName = watchName;
        this.index = index;
        this.query = query;
        this.condition = condition;
        this.action = action;
        this.throttleTimeSeconds = throttleTimeSeconds;
    }

    public Watch() {
    }

    /**
     * @return the watchName
     */
    public String getWatchName() {
        return watchName;
    }

    /**
     * @param watchName the watchName to set
     */
    public void setWatchName(String watchName) {
        this.watchName = watchName;
    }

    /**
     * @return the index
     */
    public String getIndex() {
        return index;
    }

    /**
     * @param index the index to set
     */
    public void setIndex(String index) {
        this.index = index;
    }

    /**
     * @return the query
     */
    public String getQuery() {
        return query;
    }

    /**
     * @param query the query to set
     */
    public void setQuery(String query) {
        this.query = query;
    }

    /**
     * @return the condition
     */
    public String getCondition() {
        return condition;
    }

    /**
     * @param condition the condition to set
     */
    public void setCondition(String condition) {
        this.condition = condition;
    }

    /**
     * @return the action
     */
    public String getAction() {
        return action;
    }

    /**
     * @param action the action to set
     */
    public void setAction(String action) {
        this.action = action;
    }

    /**
     * @return the throttleTimeSeconds
     */
    public int getThrottleTimeSeconds() {
        return throttleTimeSeconds;
    }

    /**
     * @param throttleTimeSeconds the throttleTimeSeconds to set
     */
    public void setThrottleTimeSeconds(int throttleTimeSeconds) {
        this.throttleTimeSeconds = throttleTimeSeconds;
    }

}
