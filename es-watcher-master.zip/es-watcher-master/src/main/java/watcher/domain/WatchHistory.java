package watcher.domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;


@Document(indexName="watch_history", type="entry", shards=1, replicas=0, refreshInterval="-1")
public class WatchHistory {

    @Id
    private String id;
    private String timestamp;
    private String watchName;
    private boolean activated;
    private boolean notified;


    public WatchHistory() {
    }

    /**
     * @param timestamp
     * @param watchName
     * @param activated
     * @param notified
     */
    public WatchHistory(String timestamp, String watchName, boolean activated, boolean notified) {
        this.timestamp = timestamp;
        this.watchName = watchName;
        this.activated = activated;
        this.notified = notified;
    }

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return the timestamp
     */
    public String getTimestamp() {
        return timestamp;
    }

    /**
     * @param timestamp the timestamp to set
     */
    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    /**
     * @return the watcherName
     */
    public String getWatchName() {
        return watchName;
    }

    /**
     * @param watcherName the watcherName to set
     */
    public void setWatchName(String watcherName) {
        this.watchName = watcherName;
    }

    /**
     * @return the activated
     */
    public boolean isActivated() {
        return activated;
    }

    /**
     * @param activated the activated to set
     */
    public void setActivated(boolean activated) {
        this.activated = activated;
    }

    /**
     * @return the notified
     */
    public boolean isNotified() {
        return notified;
    }

    /**
     * @param notified the notified to set
     */
    public void setNotified(boolean notified) {
        this.notified = notified;
    }

}
