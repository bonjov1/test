package watcher.domain;

public class SearchResult {

    private long totalHits; 
    /**
     * @param totalHits
     */
    public SearchResult(long totalHits) {
        this.totalHits = totalHits;
    }

    /**
     * @return the totalHits
     */
    public long getTotalHits() {
        return totalHits;
    }

    /**
     * @param totalHits the totalHits to set
     */
    public void setTotalHits(long totalHits) {
        this.totalHits = totalHits;
    }

}
