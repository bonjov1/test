package watcher.repository;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Component;

import watcher.domain.Watch;

@Component
public interface WatchRepository extends ElasticsearchRepository<Watch, String> {
}
