package watcher.repository;

import java.util.List;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import watcher.domain.WatchHistory;

public interface WatchHistoryRepository extends ElasticsearchRepository<WatchHistory, String> {
    List<WatchHistory> findByWatchNameAndTimestampBetweenAndNotified(
        String watchName, String from, String to, boolean notified);

}

